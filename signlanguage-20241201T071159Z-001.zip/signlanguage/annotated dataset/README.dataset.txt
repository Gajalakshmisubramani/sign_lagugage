# sign_language > 2024-11-30 1:18pm
https://universe.roboflow.com/hey-buddy/sign_language-puptv

Provided by a Roboflow user
License: CC BY 4.0

